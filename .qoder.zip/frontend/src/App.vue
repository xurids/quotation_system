<template>
  <el-config-provider>
    <router-view />
  </el-config-provider>
</template>

<style>
body { margin: 0; padding: 0; font-family: "PingFang SC", "Microsoft YaHei", sans-serif; }
</style>
